const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser')
const express = require('express');
const Busboy = require('busboy');
const cors = require('cors');
const { format } = require('path');
const spawn = require("child_process").spawn;

var app = express();
app.use(bodyParser.json());
app.use(cors());
app.use('/', express.static('./public'));

//asynchronous function to run python scripts
async function pythonFn(pyName, fName, arg, format) {

    const pyFunction = spawn('python3', [pyName, 'uploads/' + fName, arg, format]);

    pyFunction.stderr.on('data', (data) => {
        console.log(`stderr: ${data}`);
    });

    const exitCode = await new Promise((resolve, reject) => {
        pyFunction.on('close', resolve);
    });

    if (exitCode) {
        throw new Error(`Python error exit ${exitCode}`);
    }
};

var fileName;
app.get('/', (req, res) => {
    res.sendStatus(200);
});

app.post('/upload', async (req, res) => {

    //upload endpoint using busboy pipe & stream to upload
    var busboy = new Busboy({ headers: req.headers });
    busboy.on('file', function (fieldname, file, filename, encoding, mimetype) {
        fileName = filename;
        var saveTo = path.join(__dirname, 'uploads/' + filename);
        file.pipe(fs.createWriteStream(saveTo));
    });

    busboy.on('finish', function () {
        res.sendStatus(200);
    });
    return req.pipe(busboy);
});

app.post('/convert', async (req, res) => {

    await pythonFn('convert.py', fileName)
        .then(() => {
            res.sendStatus(200);
        })
        .catch(err => {
            console.log(err);
            res.sendStatus(500);
        });
});

app.post('/filter', async (req, res) => {

    const data = req.body[0];
    const format = req.body[1].format;
    var filters = {};

    //removing all null values from filters
    const keysArray = Object.keys(data);
    for (var key of keysArray) {
        if (data[key]) {
            filters[key.toString()] = data[key];
        }
    }
    filters = JSON.stringify(filters);

    await pythonFn('filter.py', fileName, filters, format)
        .then(() => {
            res.sendStatus(200);
        })
        .catch(err => {
            console.log(err);
            res.sendStatus(500);
        });
})

app.listen(4000, () => {
    console.log('server running on port 4000\n');
    console.log(`Click here to run : http://localhost:4000`);
})