import csv
import json
import sys
import pandas as pd

fileName = (sys.argv[1].split('/')[1]).split('.')[0] + '.csv'
fieldnames = ['IP-Address', 'User-Agent','X-Request-From','Request-Type','API','User-Login','User-Name','EnterpriseId','EnterpriseName','Auth-Status','Status-Code','Response-Time', 'Request-Body']
data = pd.read_csv('uploads/' + fileName, usecols=fieldnames)

filterJson = json.loads(sys.argv[2])
filteredData = data

#filtering by given parameters, if parameter is int, we use eval() to deal with TypeErrors
for i in filterJson:
    if i in ['Status-Code', 'EnterpriseId']: #both int values
        filteredData = filteredData[(data[i] == eval(filterJson[i]))]
    else:
        filteredData = filteredData[(data[i] == filterJson[i])]

if sys.argv[3] == "JSON":
    newFileName = 'Filtered' + fileName.split('.')[0]+'.json'
    filteredData.to_json('filtered_files/' + newFileName, orient='records')
else:
    #removing prefix of row number (index) to save more space
    filteredData.set_index('IP-Address', inplace=True)
    
    newFileName = 'Filtered' + fileName.split('.')[0]+'.csv'
    filteredData.to_csv('filtered_files/' + newFileName)
print ('filtered')