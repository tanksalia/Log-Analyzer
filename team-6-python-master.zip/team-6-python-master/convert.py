import csv
import sys
from itertools import islice

fileName = sys.argv[1]
fileCsvName = fileName.split('.')[0] + '.csv'

try:
    with open(fileCsvName, 'w') as file:
        fieldnames = ['IP-Address', 'User-Agent','X-Request-From','Request-Type','API','User-Login','User-Name','EnterpriseId','EnterpriseName','Auth-Status','Status-Code','Response-Time', 'Request-Body']
        
        #writing column headers
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()

        f = open(fileName)
        while True:
            #processing 100000 lines at a time to handle memory issues
            nextLines = list(islice(f, 100000))
            if nextLines:
                string = list()
                for i in range(1, len(nextLines), 2):
                    line = nextLines[i].strip()
                    log2 = line.replace('#,!',',').replace('=',',').split(',')
                    string += [str(log2[j]) + ',' for j in range(1, len(log2), 2)] + ['\n']
                file.writelines(string)
            else:
                break
except:
    raise Exception
    