import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios';
import './home.css';

export default class Home extends Component {

	//state variables to enable/disable buttons
	state = {
		selectedFile: null,
		uploadEnable: false,
		convertEnable: false,
		filterEnable: false
	};

	onFileChange = (event) => {
		// Update the state of selectedFile prop
		this.setState({
			selectedFile: event.target.files[0],
			convertEnable: false,
			filterEnable: false
		});

		//restricting uploads to only .txt/.log/.csv 
		const fileType = (event.target.files[0].type).toString();
		if (fileType === "text/plain" || fileType === "text/csv" || fileType === "text/x-log") {
			this.setState({
				uploadEnable: true
			});
		}
	}

	// function called when upload is clicked
	onFileUpload = () => {
		if (this.state.selectedFile) {

			this.setState({
				uploadEnable: false,
				convertEnable: false
			});

			//creating formdata object for file upload to server
			const formData = new FormData();

			formData.append(
				"file",
				this.state.selectedFile
			);

			// making a post request to backend api for uploading file to server folder
			axios.post("http://localhost:4000/upload", formData)
				.then(res => {
					toast.success('Upload successful! Your file is now in the uploads folder', {
						position: "bottom-right",
						autoClose: 10000
					});

					//if uploaded file is csv, user can directly filter, else user must convert
					const fileType = (this.state.selectedFile.type).toString();
					if (fileType === "text/plain" || fileType === "text/x-log") {
						this.setState({
							convertEnable: true
						});
					}
					else if (fileType === "text/csv") {
						this.setState({
							filterEnable: true
						});
					}
				})
				.catch(err => {
					toast.error('Error while uploading! Try again', {
						position: "bottom-right",
						autoClose: 10000
					});
					console.log(err);
					this.setState({
						uploadEnable: true,
						convertEnable: false
					});
				})
		}
	};

	onFileConvert = () => {

		this.setState({
			convertEnable: false
		});

		// making a post request to backend api for converting to csv
		axios.post("http://localhost:4000/convert")
			.then(res => {
				toast.success('Conversion successful! Your csv file is in the uploads folder', {
					position: "bottom-right",
					autoClose: 10000
				});
				this.setState({
					uploadEnable: false,
					filterEnable: true
				});
			})
			.catch(err => {
				toast.error('Error while converting', {
					position: "bottom-right",
					autoClose: 10000
				}
				);
				this.setState({
					uploadEnable: true,
					convertEnable: true
				});
			});
	};

	//function to display file info once file is chosen
	fileData = () => {
		
		if (this.state.selectedFile) {

			//checking if filesize should be displayed in kb, mb or gb
			var fileSize = Math.round((this.state.selectedFile.size) / 1000000.0);
			var ext = 'mb';
			if (fileSize > 1000) {
				fileSize = fileSize / 1000;
				ext = 'gb';
			}
			if (this.state.selectedFile.size < 1000000) {
				fileSize = this.state.selectedFile.size / 1000;
				ext = 'kb';
			}
			return (
				<div>
					<p>File Name: {this.state.selectedFile.name}</p>
					<p>File Type: {this.state.selectedFile.type}</p>
					<p>File Size: {fileSize.toString() + ext}</p>
					<p>Last Modified: {this.state.selectedFile.lastModifiedDate.toString()}</p>
				</div>
			);
		}
	};

	render() {

		return (
			<div className="container">
				<h1>
					Log Analyser
				</h1>
				<h5>
					(Only .txt/.log/.csv files can be uploaded)
				</h5>
				<hr />
				<div className="file-container">
					<div className="upload-info">
						<h3>
							Upload your log file
						</h3>
						<hr style={{ paddingBottom: 15 }} />
						<input type="file" onChange={this.onFileChange} />
						<p style={{ paddingTop: 20 }}>
							Log files in the following format are supported:
						</p>
						<p style={{ fontSize: 12 }}>
							2018-09-18 04:49:41,946 ERROR (default task-127)
						</p>
						<p style={{ fontSize: 12 }}>
							IP-Address=157.49.141.133#, !User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64;Trident/7.0; rv:11.0) like Gecko#, !X-Request-From=UIX#, !Request-Type=DELETE#, !API=/v2/developers#, !User-Login=test@demo.com#, !User-Name=testUser#, !EnterpriseId=2#, !EnterpriseName=Enterprise-2#, !Auth-Status=#, !Status-Code=200#, !Response-Time=1117#, !Request-Body=
						</p>
					</div>
					<div className="file-info">
						<h3 style={{ textAlign: "center" }}>File Details:</h3>
						<hr style={{ paddingBottom: 20 }} />
						{this.fileData()}
					</div>
				</div>
				<div className="form-group">
					<ToastContainer newestOnTop/>
				</div>
				<button className="btn btn-light" style={{ fontSize: 20 }} disabled={!this.state.uploadEnable} onClick={this.onFileUpload}>
					Upload
				</button>
				<button className="btn btn-light" style={{ fontSize: 20, marginLeft: 20 }} disabled={!this.state.convertEnable} onClick={this.onFileConvert}>
					Convert
				</button>
				<Link to="./Process" className="convert-btn">
					<button className="btn btn-success" style={{ fontSize: 20, marginLeft: 20 }} disabled={!this.state.filterEnable}>
						Filter ={`>`}
					</button>
				</Link>
			</div>
		);
	}
}