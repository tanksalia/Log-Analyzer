import React, { Component } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import { Link } from 'react-router-dom';
import 'react-toastify/dist/ReactToastify.css';
import Dropdown from 'react-dropdown';
import 'react-dropdown/style.css';
import axios from 'axios';
import './process.css';

export default class Process extends Component {
    constructor() {
        super();
        this.state = {
            IPAddress: null,
            userAgent: null,
            requestFrom: null,
            statusCode: null,
            requestType: null,
            api: null,
            userLogin: null,
            userName: null,
            enterpriseId: null,
            enterpriseName: null,
            loading: false,
            message: null,
            filterEnable: false,
            outputFormat: [
                'CSV',
                'JSON'
            ],
            selectedOption: null
        };
        //binding function to each object
        this.dataChange = this.dataChange.bind(this);
    }

    dataChange(event) {
        //setting value for each input
        this.setState({
            [event.target.name]: event.target.value,
            filterEnable: true
        });
    }

    //to set value for output format dropdown
    onSelect = (selectedOption) => {
        this.setState({
            selectedOption,
            filterEnable: true
        });
    };

    postData(ev) {
        //preventing page reload
        ev.preventDefault();

        const IPAddress = this.state.IPAddress
        const userAgent = this.state.userAgent
        const requestFrom = this.state.requestFrom
        const statusCode = this.state.statusCode
        const requestType = this.state.requestType
        const api = this.state.api
        const userLogin = this.state.userLogin
        const userName = this.state.userName
        const enterpriseId = this.state.enterpriseId
        const enterpriseName = this.state.enterpriseName

        //default format is csv
        const format = this.state.selectedOption ? this.state.selectedOption : { "value": "CSV" }

        this.setState({
            loading: true,
            filterEnable: false
        })

        const data = [
            {
                "IP-Address": IPAddress,
                "User-Agent": userAgent,
                "X-Request-From": requestFrom,
                "Status-Code": statusCode,
                "Request-Type": requestType,
                "API": api,
                "User-Login": userLogin,
                "User-Name": userName,
                "EnterpriseId": enterpriseId,
                "EnterpriseName": enterpriseName,
            },
            {
                "format": format.value
            }
        ]

        //sending request to api to filter using given params in request body
        axios.post('http://localhost:4000/filter', data)
            .then(response => {
                toast.success('Filter applied! Output is in the filtered_files folder', {
                    position: "bottom-right",
                    autoClose: 10000
                });
                this.setState({
                    loading: false,
                    message: response.data,
                })
            })
            .catch(err => {
                console.log(err);
                this.setState({
                    loading: false,
                    filterEnable: true
                })
            })
    }

    review() {
        if (this.state.loading) {
            return <p> Filtering data... </p>
        }
        else {
            return <p> {this.state.message}</p>
        }
    }

    render() {
        const { selectedOption } = this.state;
        return (
            <div className="container">
                <h1>Filter logs from the input file by parameter</h1>
                <h6>(Input field can be left empty if it is not needed to filter by a particular parameter)</h6>
                <div className="filter-form">
                    <form className="form-wrapper" onSubmit={this.postData.bind(this)}>
                        <div className="top-div-wrapper">
                            <div className="input-left-wrapper">
                                <input type="text" name="IPAddress" value={this.state.IPAddress} onChange={this.dataChange.bind(this)} placeholder="IP-Address" /> <br /><br />

                                <input type="text" name="userAgent" value={this.state.userAgent} onChange={this.dataChange.bind(this)} placeholder="User-Agent" /> <br /><br />

                                <input type="text" name="requestFrom" value={this.state.requestFrom} onChange={this.dataChange.bind(this)} placeholder="Request-From" /><br /><br />

                                <input type="text" name="requestType" value={this.state.requestType} onChange={this.dataChange.bind(this)} placeholder="Request-Type" /><br /><br />

                                <input type="text" name="api" value={this.state.api} onChange={this.dataChange.bind(this)} placeholder="API" /><br /><br />

                            </div>
                            <div className="input-right-wrapper">
                                <input type="text" name="userLogin" value={this.state.userLogin} onChange={this.dataChange.bind(this)} placeholder="User-Login" /><br /><br />

                                <input type="text" name="userName" value={this.state.userName} onChange={this.dataChange.bind(this)} placeholder="User-Name" /><br /><br />

                                <input type="text" name="enterpriseId" value={this.state.enterpriseId} onChange={this.dataChange.bind(this)} placeholder="EnterpriseId" /><br /><br />

                                <input type="text" name="enterpriseName" value={this.state.enterpriseName} onChange={this.dataChange.bind(this)} placeholder="EnterpriseName" /> <br /><br />

                                <input type="text" name="statusCode" value={this.state.statusCode} onChange={this.dataChange.bind(this)} placeholder="Status-Code" /><br /><br />
                            </div>
                        </div>
                        <p>
                            Default format is CSV
                        </p>
                        <div className="button-wrapper">
                            <Dropdown className="dropdown-output" name="format" options={this.state.outputFormat} onChange={this.onSelect.bind(this)} value={selectedOption} style={{ width: 10 }} placeholder="Output Format" /> <br />

                            <button type="submit" className="btn btn-success" style={{ fontSize: 24, paddingLeft: 20, paddingRight: 30 }} disabled={!this.state.filterEnable}>
                                Apply filter
					        </button>
                            <div className="form-group">
                                <ToastContainer />
                            </div>
                        </div>
                    </form>
                    <Link to="/">
                        <button className="btn btn-light" style={{ fontSize: 16 }}>
                            {`<`}- Upload different file
					    </button>
                    </Link>
                    {this.review()}
                </div>
            </div>
        )
    }
}