# team-6-python

## Installation

```npm install``` to install all dependencies

## Run

```npm start``` to start server

Go to ```http://localhost:4000``` to view and run application
